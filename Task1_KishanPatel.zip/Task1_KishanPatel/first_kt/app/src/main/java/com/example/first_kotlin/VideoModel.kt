package com.example.first_kotlin

data class VideoModel(
    val title: String,
    val videoId: String
)
