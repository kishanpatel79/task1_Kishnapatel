package com.example.first_kotlin

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class VideoAdapter(private val videoList: List<VideoModel>) :
    RecyclerView.Adapter<VideoAdapter.VideoViewHolder>() {

    class VideoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(R.id.videoTitle)
        val webView: WebView = itemView.findViewById(R.id.videoWebView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VideoViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.video_item, parent, false)
        return VideoViewHolder(view)
    }

    override fun onBindViewHolder(holder: VideoViewHolder, position: Int) {
        val video = videoList[position]
        holder.title.text = video.title
        val videoHtml = "<iframe width=\"100%\" height=\"100%\" src=\"https://www.youtube.com/embed/${video.videoId}\" frameborder=\"0\" allowfullscreen></iframe>"
        holder.webView.settings.javaScriptEnabled = true
        holder.webView.settings.loadWithOverviewMode = true
        holder.webView.settings.useWideViewPort = true
        holder.webView.loadData(videoHtml, "text/html", "utf-8")
    }

    override fun getItemCount() = videoList.size
}
