package com.example.first_kotlin

import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: VideoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val videoList = listOf(
            VideoModel("TMKOC Comedy ", "c_Nedcq3Aw0"), // embeddable
            VideoModel(" Dhruv Rathee", "lD3SadhsQNg"),
            VideoModel("Ashish Chanchlani Comedy", "d72vXhJDE6M"),
            VideoModel("Karan Aujla(MAHOL POORA WAVY!!!)", "XTp5jaRU3Ws")

        ).shuffled() // random order

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        adapter = VideoAdapter(videoList)
        recyclerView.adapter = adapter
    }
}
